* создаете виртуальное окружение
* активируете 
* /admin - username% admin / pass: admin
* 