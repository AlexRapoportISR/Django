from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views.generic import TemplateView


class DashboardView(LoginRequiredMixin, TemplateView):
    """Личный кабинет пользователя. Вход авторизованным пользователям"""
    template_name = 'dashboard.html'
    